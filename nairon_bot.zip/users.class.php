<?php

class Users
{



    public function createUser($user_id, $chat_id, $username, $firstname)
    {

        global $db;

        $time = time();
        $date = date("d/m/y");
        $balance = 0.00000000;
        $phone = "empty";
        $password = "empty";
        $pending_action = "empty";
        $pending_action_data = "empty";
        // $result = $db->setQuery("INSERT INTO users (user_id, chat_id, username, firstname, balance, mining_time, have_started_mining, wallet_address, withdrawal_pin, mining_plan, time, date) VALUES ('$user_id', '$chat_id', '$username', '$firstname', '0.00000000', '0', 'no', 'empty', 'empty', 'empty', '$time', '$date');");
        $result = $db->setHandlerQuery("INSERT INTO users (user_id, chat_id, username, firstname, phone, password, balance, pending_action, pending_action_data, time, date) VALUES ('$user_id', '$chat_id', '$username', '$firstname', '$phone', '$password', '$balance', '$pending_action', '$pending_action_data', '$time', '$date');");
    }

    public function userExists($user_id)
    {
        global $db;

        $result = $db->setHandlerQuery("SELECT * FROM users WHERE user_id='$user_id';");
        $numrows = $db->numrows($result);

        if ($numrows != 0) {
            return true;
        } else {
            return false;
        }
    }

    public function getUserDetail($user_id, $detail)
    {
        global $db;

        $result = $db->setHandlerQuery("SELECT * FROM users WHERE user_id='$user_id';");
        $row = $result[0];

        return $row[$detail];
    }

    public function setUserDetail($user_id, $detail, $value)
    {
        global $db;

        $result = $db->setHandlerQuery("UPDATE users SET $detail='$value' WHERE user_id='$user_id';");
    }
}

$user = new Users();
